from resources.lib import run_addon
if __name__ == "__main__":
    run_addon.run()