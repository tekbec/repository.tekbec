from resources.lib import run_service
if __name__ == "__main__":
    run_service.run()