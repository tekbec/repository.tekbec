API_KEY = '8235861265252'
API_URL = f'https://www.thesportsdb.com/api/v1/json/{API_KEY}'
TV_EVENTS_PATH = '/eventstv.php?d={date}'
SCHEDULE_PATH = '/eventsday.php?d={date}'